#!/bin/sh

#define Variables
flagPath="/project/bddf/ro3c/storage/FLAGS"
logPath="/project/bddf/ro3c/logs"


# $1 : workFlow Id
# $2 : l'ID de l'action

delimiter='@'
delimiter2='_'
JOB_NAME=$1$delimiter$2


#Get the yarn job from AM
GET_JOB="yarn application -list -appStates ALL | grep  'A=$2:ID=$1'"
YARN_JOB=$(eval "$GET_JOB")

#Extract the application ID and pass it to the yarn log function
APPLICATION_CODE="echo "$YARN_JOB" | grep -o -E 'application_[^ ]+'"
APPLICATION_ID=$(eval "$APPLICATION_CODE")

#Extract YARN LOG
YARN_LOG="yarn logs -applicationId $APPLICATION_ID"


#Write log in local file
eval "$YARN_LOG" > $3$delimiter2$JOB_NAME.log


#Copy the file to HDFS
hdfs dfs -put $3$delimiter2$JOB_NAME.log $logPath

hdfs dfs -mv $flagPath/$3/TALEND_SUCCESS $flagPath/$3/OOZIE_ERROR


